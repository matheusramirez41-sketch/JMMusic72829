/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "bf1580b4326c45177b0ac0bfa2714eb7"
  }, {
    "url": "pwa-512x512.png",
    "revision": "107c6a091648edfb533e4167a1dbc3ea"
  }, {
    "url": "pwa-192x192.png",
    "revision": "9450b8fa4e8ff7d60c4c4b8c0054adeb"
  }, {
    "url": "index.html",
    "revision": "e1dfffc75af9f769654613441fdc76d7"
  }, {
    "url": "icon.svg",
    "revision": "a43c8ce155618085467c87650f2fefea"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "16101ddbc4eb815ff68b890a06e9ee1a"
  }, {
    "url": "assets/index-BpnUPs0-.js",
    "revision": null
  }, {
    "url": "assets/index-B0TbiYfm.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "16101ddbc4eb815ff68b890a06e9ee1a"
  }, {
    "url": "icon.svg",
    "revision": "a43c8ce155618085467c87650f2fefea"
  }, {
    "url": "pwa-192x192.png",
    "revision": "9450b8fa4e8ff7d60c4c4b8c0054adeb"
  }, {
    "url": "pwa-512x512.png",
    "revision": "107c6a091648edfb533e4167a1dbc3ea"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "bf1580b4326c45177b0ac0bfa2714eb7"
  }, {
    "url": "manifest.webmanifest",
    "revision": "99f6246d230f93580da32bfeaac172c7"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/images\.unsplash\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "artwork-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 100,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/.*(\.mp3|\.ogg|\.m4a|\.wav).*/i, new workbox.CacheFirst({
    "cacheName": "audio-offline-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 50,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
